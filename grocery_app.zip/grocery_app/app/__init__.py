from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from config import Config

db = SQLAlchemy()

def create_app():
    app = Flask(__name__)

    # ✅ Load configuration from config.py
    app.config.from_object(Config)

    db.init_app(app)

    # ✅ Import model after initializing db
    from app.models import Product  

    # ✅ Import and register blueprints
    from app.routes import main
    app.register_blueprint(main)

    with app.app_context():
        db.create_all()  # ✅ Automatically create tables at startup
        print(f"✅ Database initialized! Using {app.config['SQLALCHEMY_DATABASE_URI']}")

    return app
