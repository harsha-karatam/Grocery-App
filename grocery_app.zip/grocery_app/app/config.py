import os

DB_USER = "harsha"
DB_PASSWORD = "harsha123"
DB_HOST = "35.154.152.124"  # Change this to the EC2 instance's IP where MySQL is running
DB_NAME = "grocery_db"

class Config:
    SQLALCHEMY_DATABASE_URI = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:3306/{DB_NAME}"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
