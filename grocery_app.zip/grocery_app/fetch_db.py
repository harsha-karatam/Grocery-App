from app import create_app, db
from app.models import Product

app = create_app()

with app.app_context():
    # ✅ Insert a test product
    if not Product.query.first():  # Only insert if no product exists
        sample_product = Product(name="Banana", price=0.99, stock=50)
        db.session.add(sample_product)
        db.session.commit()
        print("✅ Test product 'Banana' added!")

    # ✅ Fetch all products
    products = Product.query.all()

    print("\n📦 Stored Products in Database:")
    if not products:
        print("⚠️ No products found!")
    for product in products:
        print(f"🛒 {product.name} - 💲{product.price} - Stock: {product.stock}")
