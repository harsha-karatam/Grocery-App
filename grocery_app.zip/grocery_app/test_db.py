from app import create_app, db
from app.models import Product

app = create_app()

with app.app_context():
    db.create_all()
    print("✅ Tables created successfully!")

    # Test inserting a product
    product = Product(name="Apple", price=1.5, stock=100)
    db.session.add(product)
    db.session.commit()
    print("✅ Sample product added!")
